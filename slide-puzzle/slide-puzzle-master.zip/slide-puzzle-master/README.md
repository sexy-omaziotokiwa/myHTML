# [Slide Puzzle](https://youtu.be/sD3Os4H_EOU)
- Coding Tutorial: https://youtu.be/sD3Os4H_EOU
- Demo: https://imkennyyip.github.io/slide-puzzle/

In this tutorial, you will learn how to create a doraemon-themed slide puzzle using mouse click drag events!

![slide-puzzle-preview](https://user-images.githubusercontent.com/78777681/163032087-dd7f31fc-b3bb-43ba-baee-2ebbef28dd35.png)
