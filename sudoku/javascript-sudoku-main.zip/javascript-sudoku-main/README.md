# javascript-sudoku

    Make Sudoku Game With HTML CSS JavaScript

# Video tutorial

    https://youtu.be/xpsm3tOLTVE

# Resource

    Google font: https://fonts.google.com/

    Boxicons: https://boxicons.com/

    Images: https://unsplash.com/

# Preview

!["Make Sudoku Game With HTML CSS JavaScript"](https://user-images.githubusercontent.com/67447840/135793517-57b1d971-67c5-4561-bd70-43f26998a108.jpg "Make Sudoku Game With HTML CSS JavaScript")
