## Sudoku Web App
 sudoku web app is a legacy sudoku game on the internet running in your browser .
 The sole purpose of this game is to just check my html js and flask routing skills . 
 This app is deployed on Heroku here :- https://sudoku-web-game.herokuapp.com/
## How to play Sudoku game
 Actually i know almost 80% of you know how to play sudoku game and rest 20% can google it but just to fill this Readme file and also for those 20% people i will tell how to play this game
    In this game there is a grid of 81 (9x9) cell i.e 9 cell in a row and 9 cell in a column there are 9 subgrid contaning 9 cell (3x3) . There are some cell pre filled (called hints) depending upon level of difficulty.
    Now we have to fill the grid with number 1-9 keeping in mind that no number repeat in a row ,coloumn & sub grid . you can read detailed explanation with example somewhere on inernet just google it.

## Now let's Talk about code:
 As the name suggest this web app or website is made with the help of flask frame-work of python and you can see the percentage of language used on the github Lanuguage used
1. python (Flask-Framework)
2. Html 
3. JavaScript & jquery (ajax)
4. cascadle style sheet (css) 

 Python is used to generate the sudoku and solve it . Javascript and Jquery is used to send data to backend python server and show the result in frontend and various logical operation in frontend 
    CSS for styling .

I think that's enough.
one more think I am open to collab so you can updated the source code and put it on your repo or can send pull request just mail me at backend.nktechnical@gmail.com after making request or you can report a bug.
